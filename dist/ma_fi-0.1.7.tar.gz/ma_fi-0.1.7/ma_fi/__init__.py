import os
import pandas as pd

# Get the path of the package directory
package_dir = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(package_dir, "ISIN_sectors_ma.csv")
